WealthSphere Project - Full Package (Part 1 + Part 2 + Part 3)
-------------------------------------------------------------
Contents:
- index.html, about.html, services.html, enquiry.html, contact.html
- css/: base.css, layout.css, components.css
- js/: main.js, part3.js
- images/: hero.webp, thumb.webp
- fonts/: placeholders (add licensed woff2 files for offline use)
- proposals/: proposal1.pdf, proposal2.pdf
- robots.txt, sitemap.xml, structured-data.json, README.md

Usage:
1. Unzip the package.
2. Run a local server (recommended): python3 -m http.server 8000
3. Open http://localhost:8000/ in your browser.
4. Replace fonts with licensed files and update GTM/GA IDs in js/part3.js before publishing.
