Accessibility checklist: headings, ARIA labels, keyboard nav, color contrast, form labels.
