Performance notes: use CDN for large images, enable gzip/Brotli, set caching headers.
