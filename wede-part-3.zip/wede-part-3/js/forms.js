document.addEventListener('DOMContentLoaded', function() {
  const forms = document.querySelectorAll('form[aria-label]');
  
  forms.forEach(function(form) {
    form.addEventListener('submit', function(e) {
      e.preventDefault();
      
      const formData = new FormData(form);
      const data = Object.fromEntries(formData.entries());
      const submitBtn = form.querySelector('button[type="submit"]');
      const originalText = submitBtn.textContent;
      
      submitBtn.disabled = true;
      submitBtn.textContent = 'Sending...';
      
      const emailBody = Object.entries(data)
        .map(function(entry) { return entry[0] + ': ' + entry[1]; })
        .join('\n');
      
      const mailto = 'mailto:info@aureumfoundation.org?subject=Enquiry from ' + (data.name || data.cname || 'Website') + '&body=' + encodeURIComponent(emailBody);
      
      const successMsg = document.createElement('div');
      successMsg.className = 'success-message';
      successMsg.innerHTML = '<strong>✓ Form Submitted!</strong><br>Your email client will open to send your message. If it doesn\'t open automatically, please email us at <a href="mailto:info@aureumfoundation.org" style="color:#080808;text-decoration:underline">info@aureumfoundation.org</a>';
      successMsg.style.cssText = 'background:var(--brand);color:#080808;padding:1rem;border-radius:8px;margin-top:1rem;font-weight:600;line-height:1.6;';
      
      const existingMsg = form.querySelector('.success-message');
      if (existingMsg) existingMsg.remove();
      
      form.appendChild(successMsg);
      
      setTimeout(function() {
        try {
          window.location.href = mailto;
        } catch(err) {
          console.log('Email client not available');
        }
        submitBtn.disabled = false;
        submitBtn.textContent = originalText;
      }, 800);
      
      setTimeout(function() { 
        if (successMsg.parentNode) successMsg.remove(); 
      }, 8000);
    });
  });
});
