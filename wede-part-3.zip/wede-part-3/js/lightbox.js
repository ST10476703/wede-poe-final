(function() {
  'use strict';

let lightboxModal;
let currentImageIndex = 0;
let galleryImages = [];

function initLightbox() {
  lightboxModal = document.getElementById('lightboxModal');
  if (!lightboxModal) return;
  
  const galleryItems = document.querySelectorAll('.gallery-item');
  galleryImages = Array.from(galleryItems);
  
  galleryItems.forEach(function(item, index) {
    item.addEventListener('click', function() { 
      openLightbox(index); 
    });
  });
  
  const closeLightboxBtn = document.getElementById('closeLightbox');
  const prevImageBtn = document.getElementById('prevImage');
  const nextImageBtn = document.getElementById('nextImage');
  
  if (closeLightboxBtn) closeLightboxBtn.addEventListener('click', closeLightbox);
  if (prevImageBtn) prevImageBtn.addEventListener('click', function() { changeImage(-1); });
  if (nextImageBtn) nextImageBtn.addEventListener('click', function() { changeImage(1); });
  
  lightboxModal.addEventListener('click', function(e) {
    if (e.target === lightboxModal) closeLightbox();
  });
  
  document.addEventListener('keydown', function(e) {
    if (lightboxModal.style.display === 'flex') {
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowLeft') changeImage(-1);
      if (e.key === 'ArrowRight') changeImage(1);
    }
  });
}

function openLightbox(index) {
  currentImageIndex = index;
  updateLightboxImage();
  lightboxModal.style.display = 'flex';
  document.body.style.overflow = 'hidden';
}

function closeLightbox() {
  lightboxModal.style.display = 'none';
  document.body.style.overflow = 'auto';
}

function changeImage(direction) {
  currentImageIndex = (currentImageIndex + direction + galleryImages.length) % galleryImages.length;
  updateLightboxImage();
}

function updateLightboxImage() {
  const img = galleryImages[currentImageIndex].querySelector('img');
  const lightboxImg = document.getElementById('lightboxImage');
  const lightboxCaption = document.getElementById('lightboxCaption');
  
  lightboxImg.src = img.dataset.full || img.src;
  lightboxImg.alt = img.alt;
  lightboxCaption.textContent = img.alt || '';
  
  document.getElementById('imageCounter').textContent = (currentImageIndex + 1) + ' / ' + galleryImages.length;
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initLightbox);
} else {
  initLightbox();
}

})();
