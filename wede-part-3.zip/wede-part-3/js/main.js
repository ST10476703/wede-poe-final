document.addEventListener('DOMContentLoaded', ()=>{
  // year stamp
  const y = document.getElementById('year'); if(y) y.textContent = new Date().getFullYear();
  // mobile nav toggle
  const btn = document.getElementById('navToggle');
  const nav = document.getElementById('primaryNav');
  if(btn && nav){
    btn.addEventListener('click', ()=>{
      const expanded = btn.getAttribute('aria-expanded') === 'true';
      btn.setAttribute('aria-expanded', String(!expanded));
      nav.style.display = expanded ? 'none' : 'flex';
    });
  }
  // simple parallax illusion
  const hero = document.querySelector('.hero');
  if(hero){
    window.addEventListener('scroll', ()=>{
      const scrolled = window.pageYOffset;
      hero.style.transform = 'translateY(' + (scrolled * 0.06) + 'px)';
    });
  }
});
