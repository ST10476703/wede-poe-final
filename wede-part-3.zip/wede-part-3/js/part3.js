// analytics placeholders (replace IDs before production)
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
// Cookie consent simple
function setCookie(name,value,days){var d=new Date();d.setTime(d.getTime()+(days*24*60*60*1000));document.cookie=name+'='+value+';path=/;expires='+d.toUTCString();}
function getCookie(name){var v=document.cookie.match('(^|;) ?'+name+'=([^;]*)(;|$)');return v?v[2]:null;}
function showCookie(){ if(!getCookie('ws_consent')){var c=document.createElement('div');c.id='cookie-consent';c.innerHTML='<div role="dialog" aria-live="polite" style="position:fixed;left:1rem;right:1rem;bottom:1rem;background:#111;padding:1rem;border-radius:8px;display:flex;justify-content:space-between;align-items:center;gap:1rem;">'+ '<span>We use cookies for analytics and performance. <a href="/privacy.html" style="color:var(--brand)">Privacy</a></span><div><button id="acceptCookies" style="background:var(--brand);border:none;padding:.6rem 1rem;border-radius:8px;">Accept</button><button id="declineCookies" style="background:transparent;border:1px solid #333;color:var(--fg);padding:.6rem 1rem;border-radius:8px;margin-left:.5rem">Decline</button></div></div>';document.body.appendChild(c);document.getElementById('acceptCookies').addEventListener('click',function(){setCookie('ws_consent','yes',365);c.remove();});document.getElementById('declineCookies').addEventListener('click',function(){setCookie('ws_consent','no',365);c.remove();});}}
document.addEventListener('DOMContentLoaded', showCookie);
