(function() {
  'use strict';

const searchData = [
  {
    title: 'Home - Wealth with Purpose',
    url: 'index.html',
    content: 'Aureum Foundation channels elite capital into enduring education and innovation outcomes across Africa. Education endowments scholarships leadership academies digital labs. Innovation funding seed capital research venture studios. Global partnerships world-class institutions family offices.'
  },
  {
    title: 'About - Mission & Leadership',
    url: 'about.html',
    content: 'Aureum Foundation aligns wealth with long-horizon outcomes. Fund education and innovation that compounds. Mobilise high-net-worth capital for scalable education and innovation. Africa where talent meets infrastructure and capital at speed. Leadership Dana Mokoena Idris van der Merwe.'
  },
  {
    title: 'Services - Our Ventures',
    url: 'services.html',
    content: 'Education initiatives scholarships STEM academies digital labs. Innovation funding seed grants venture build studios research translation. Global partnerships co-funding institutions family offices governance impact tracked.'
  },
  {
    title: 'Enquiry - Sponsor a Venture',
    url: 'enquiry.html',
    content: 'Submit sponsorship donation volunteer partner interest. Join Aureum Foundation impact across Africa.'
  },
  {
    title: 'Contact - Get in Touch',
    url: 'contact.html',
    content: 'Contact Aureum Foundation Cape Town V&A Waterfront London St James office locations phone email.'
  }
];

let searchModal;

function initSearch() {
  const searchInput = document.getElementById('searchInput');
  const searchBtn = document.getElementById('searchBtn');
  searchModal = document.getElementById('searchModal');
  const searchResults = document.getElementById('searchResults');
  const closeSearch = document.getElementById('closeSearch');
  
  if (!searchInput || !searchBtn || !searchModal) return;
  
  searchBtn.addEventListener('click', openSearch);
  closeSearch.addEventListener('click', closeSearchModal);
  searchModal.addEventListener('click', function(e) {
    if (e.target === searchModal) closeSearchModal();
  });
  
  let debounceTimer;
  searchInput.addEventListener('input', function(e) {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(function() { 
      performSearch(e.target.value, searchResults);
    }, 300);
  });
  
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && searchModal.style.display === 'flex') {
      closeSearchModal();
    }
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
      e.preventDefault();
      openSearch();
    }
  });
}

function openSearch() {
  searchModal.style.display = 'flex';
  document.getElementById('searchInput').focus();
}

function closeSearchModal() {
  searchModal.style.display = 'none';
  document.getElementById('searchInput').value = '';
  document.getElementById('searchResults').innerHTML = '';
}

function performSearch(query, resultsContainer) {
  if (!query || query.length < 2) {
    resultsContainer.innerHTML = '<p style="color:var(--muted);padding:1rem;">Type to search...</p>';
    return;
  }
  
  const lowerQuery = query.toLowerCase();
  const results = searchData.filter(function(item) {
    return item.title.toLowerCase().includes(lowerQuery) || 
           item.content.toLowerCase().includes(lowerQuery);
  });
  
  if (results.length === 0) {
    resultsContainer.innerHTML = '<p style="color:var(--muted);padding:1rem;">No results found.</p>';
    return;
  }
  
  resultsContainer.innerHTML = results.map(function(result) {
    const snippet = getSnippet(result.content, lowerQuery);
    return '<a href="' + result.url + '" class="search-result-item">' +
           '<h3>' + highlightMatch(result.title, query) + '</h3>' +
           '<p>' + highlightMatch(snippet, query) + '</p>' +
           '</a>';
  }).join('');
}

function getSnippet(content, query) {
  const index = content.toLowerCase().indexOf(query);
  if (index === -1) return content.substring(0, 150) + '...';
  
  const start = Math.max(0, index - 50);
  const end = Math.min(content.length, index + 100);
  return (start > 0 ? '...' : '') + content.substring(start, end) + (end < content.length ? '...' : '');
}

function highlightMatch(text, query) {
  const regex = new RegExp('(' + query + ')', 'gi');
  return text.replace(regex, '<mark>$1</mark>');
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initSearch);
} else {
  initSearch();
}

})();
