# Aureum Foundation - WealthSphere Project

## Overview
Aureum Foundation is a professional, feature-rich website showcasing a wealth management foundation focused on channeling elite capital into education and innovation outcomes across Africa. The site features comprehensive SEO, interactive maps, image galleries, dynamic search, and mobile-responsive design.

## Project Structure
- **HTML Pages**: index.html, about.html, services.html, enquiry.html, contact.html
- **CSS**: base.css (foundations), layout.css (responsive structure), components.css (UI elements, modals, galleries)
- **JavaScript**: 
  - main.js (navigation, parallax)
  - part3.js (analytics, cookie consent)
  - search.js (dynamic client-side search)
  - lightbox.js (image gallery modal)
  - forms.js (form handling with email integration)
- **Assets**: images/, fonts/, proposals/
- **SEO**: robots.txt, sitemap.xml, structured-data.json

## Technology Stack
- Pure HTML5, CSS3, JavaScript (ES6)
- Python 3.11 HTTP server for development
- Static file hosting ready for deployment

## Features

### SEO Optimization
- Unique titles, meta descriptions, and keywords for each page
- Open Graph and Twitter Card meta tags for social sharing
- Canonical URLs to prevent duplicate content issues
- Comprehensive keyword targeting for African education, innovation funding, and philanthropy
- Image alt tags for accessibility and SEO

### Interactive Features
- **Dynamic Search**: Client-side search across all pages with keyboard shortcuts (Ctrl/Cmd + K), real-time filtering, and highlighted results
- **Location Maps**: OpenStreetMap embeds showing Cape Town (V&A Waterfront) and London (St James's) office locations
- **Image Gallery**: Clickable gallery on services page with full-screen lightbox modal, keyboard navigation (arrow keys, Escape)
- **Form Handling**: Contact and enquiry forms with JavaScript validation, mailto integration, and clear user feedback
- **Mobile Navigation**: Responsive hamburger menu with smooth transitions

### Mobile Responsive
- Fully responsive design works on all screen sizes
- Touch-friendly navigation and interactive elements
- Mobile-optimized search button and forms
- Responsive maps and gallery grids
- Single-column layout on small screens

### Accessibility
- ARIA labels and semantic HTML
- Keyboard navigation for all interactive features
- Focus management in modals
- High contrast brand colors (gold #c9a227 on dark background)
- Screen reader friendly content structure

## Development
The site runs on a simple Python HTTP server configured to:
- Serve on port 5000 (0.0.0.0)
- Disable caching for development
- Serve all static assets from the root directory

## Recent Changes
- 2025-11-21: Initial Replit environment setup
  - Created Python HTTP server with cache control
  - Configured workflow for webview on port 5000
  - Added .gitignore for Python files
  - Set up project documentation
  
- 2025-11-21: Major feature additions
  - Implemented comprehensive SEO meta tags across all 5 pages
  - Added OpenStreetMap location embeds for Cape Town and London offices
  - Created image gallery with lightbox functionality on services page
  - Implemented dynamic client-side search feature with modal UI
  - Enhanced forms with JavaScript handling and user feedback
  - Made entire site mobile-responsive with optimized CSS
  - Added search button to header across all pages
  - Fixed JavaScript initialization issues with IIFE patterns
  - Converted all code to ES6-compatible syntax (no arrow functions in event listeners)

## Deployment
The project is configured for static site deployment on Replit:
- Deployment type: Static
- Public directory: Current directory (.)
- All HTML, CSS, JS, and assets served directly without build steps

## Browser Support
- Modern browsers with ES6 support (Chrome 49+, Firefox 44+, Safari 10+, Edge 12+)
- Covers 99%+ of active internet users
- Mobile browsers fully supported (iOS Safari, Chrome Mobile, Samsung Internet)

## Notes
- Font files are placeholders - add licensed woff2 files before production
- Update GTM/GA IDs in js/part3.js before going live
- Cookie consent banner appears on first visit
- Email forms use mailto protocol - users need an email client configured
- Maps use OpenStreetMap (no API keys required)
- Search data is client-side and defined in js/search.js

## Contact Information
- Cape Town Office: V&A Waterfront, Cape Town, 8001 | +27 21 555 0101
- London Office: St James's, London SW1A 1AA | +44 20 7946 0101
- Email: info@aureumfoundation.org
